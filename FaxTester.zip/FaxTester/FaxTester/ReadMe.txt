-------------------------------------------------------------------------
ATTN. USERS OF CSS FAXTESTER...
-------------------------------------------------------------------------

This tool will exercise the code and DLLs that CSS will use for processing fax jobs within TouchWorks.  

Usage:

  Select a modem.
  Use the sample TIF file included in the Zip
  Enter a fax number that's near to you
  Modem Type:
    First test with the default U.S.R,I.-WNMDM33600
    If unsuccessful, try GCLASS2S/RF/ (Generic Class 2 modem)
    Still no luck, try GCLASS2.0, then GCLASS1(SFC), then GCLASS1(HFC)
    If none of these work, you are probably out of luck, but you can experiment with the Legacy check box.
  Legacy Faxing Implementation check box
    Last resort - This was kept for backward compatibility and should only be used if you absolutely can't get a successful test.

Once you've gotten a successful test, hit the save button.  This updates the registry keys that CSS will use when attempting to fax with this modem.  If you have multiple modems, pick the next modem and start the process over.  Be sure to save the settings for each modem tested if you picked a modem type other than the default.

If you aren't able to get faxing to work with this tool, you will not be able to use this hardware with CSS.  There is always the possibility that we have an issue that we can resolve with this hardware with code changes.  It never hurts to ask.

-------------------------------------------------------------------------
Version History:
	v9.0.3.1 - Created 3/12/2003 For use with TW v9.0 SP3
